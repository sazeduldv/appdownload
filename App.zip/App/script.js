document.getElementById("downloadButton").addEventListener("click", function() {
    const sound = document.getElementById("clickSound");
    sound.play();
    window.location.href = "https://dollarplaza.org/";
});

// Create falling leaves
function createLeaves() {
    const leavesContainer = document.getElementById("leavesContainer");
    for (let i = 0; i < 10; i++) {
        const leaf = document.createElement("div");
        leaf.className = "leaf";
        leaf.style.left = Math.random() * 100 + "vw";
        leaf.style.animationDelay = Math.random() * 5 + "s";
        leavesContainer.appendChild(leaf);
    }
}
createLeaves();
